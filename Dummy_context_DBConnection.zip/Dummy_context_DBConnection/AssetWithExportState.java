public class AssetWithExportState {

        ExportState state;

    public AssetWithExportState(ExportState state) {
        this.state = state;
    }
}
